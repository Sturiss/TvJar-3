package com.github.catvod.spider;




import android.content.Context;

import com.github.catvod.crawler.SpiderDebug;
import com.github.catvod.demo.MainActivity;

public class Init {


    public static void init(Context context) {
        SpiderDebug.log("自定义爬虫代码加载成功！");
    }
}
